<?php

echo "disabled";

?>